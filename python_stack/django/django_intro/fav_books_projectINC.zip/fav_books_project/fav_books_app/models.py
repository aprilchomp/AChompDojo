from django.db import models
import re

# Create your models here.
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):    ## test whether a field matches the pattern            
            errors['email'] = "Invalid email address was entered"
        if len(postData['fname']) < 3:
            errors['fname'] = "First name must be at least 3 characters"
        if len(postData['pw']) < 5:
            errors['pw'] = "Password must be at least 5 characters" 
        if postData['pw'] != postData['confirmpw']:  ##checks if passwords entered are the same
            errors['pw'] = 'Password and Confirm Password do not match'
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()

class Book(models.Model):
    title = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    # ADDING IN OUR LIKES
    user_likes = models.ManyToManyField(User, related_name='liked_posts')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

